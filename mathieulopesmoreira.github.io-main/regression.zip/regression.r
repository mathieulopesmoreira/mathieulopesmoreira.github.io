# === 1. Importation des donn�es ===
train <- read.csv2("train.csv")
test <- read.csv2("test.csv")

# === 2. Remplacement des NA ou 0 dans Surface.reel par 1 pour �viter les erreurs pour les mod�les logarithmique et puissance ===
train$Surface.reel[is.na(train$Surface.reel) | train$Surface.reel == 0] <- 1
test$Surface.reel[is.na(test$Surface.reel) | test$Surface.reel == 0] <- 1

# === 3. Initialisation de la colonne des pr�dictions ===
test$Valeur.fonciere <- 0

# === 4. Mod�les groupe par groupe ===

# --- Groupe 1 (lin�aire) ---
g1 <- c(79000)
tg1 <- subset(train, Code.postal %in% g1)
mean_x1 <- mean(tg1$Surface.reel); mean_y1 <- mean(tg1$Valeur.fonciere)
b1 <- sum((tg1$Surface.reel - mean_x1)*(tg1$Valeur.fonciere - mean_y1)) / sum((tg1$Surface.reel - mean_x1)^2)
a1 <- mean_y1 - b1 * mean_x1
test$Valeur.fonciere[test$Code.postal %in% g1] <- a1 + b1 * test$Surface.reel[test$Code.postal %in% g1]

# --- Groupe 2 (logarithmique) ---
g2 <- c(79100, 79220, 79340, 79500)
tg2 <- subset(train, Code.postal %in% g2 & Surface.reel > 0)
log_x2 <- log(tg2$Surface.reel)
mean_logx2 <- mean(log_x2); mean_y2 <- mean(tg2$Valeur.fonciere)
b2 <- sum((log_x2 - mean_logx2)*(tg2$Valeur.fonciere - mean_y2)) / sum((log_x2 - mean_logx2)^2)
a2 <- mean_y2 - b2 * mean_logx2
test$Valeur.fonciere[test$Code.postal %in% g2] <- a2 + b2 * log(test$Surface.reel[test$Code.postal %in% g2])

# --- Groupe 3 (lin�aire) ---
g3 <- c(79110, 79120, 79130, 79150, 79170, 79240, 79350, 79390, 79420, 79430, 79440, 79600)
tg3 <- subset(train, Code.postal %in% g3)
mean_x3 <- mean(tg3$Surface.reel); mean_y3 <- mean(tg3$Valeur.fonciere)
b3 <- sum((tg3$Surface.reel - mean_x3)*(tg3$Valeur.fonciere - mean_y3)) / sum((tg3$Surface.reel - mean_x3)^2)
a3 <- mean_y3 - b3 * mean_x3
test$Valeur.fonciere[test$Code.postal %in% g3] <- a3 + b3 * test$Surface.reel[test$Code.postal %in% g3]

# --- Groupe 4 (lin�aire) ---
g4 <- c(79140, 79160, 79200, 79250, 79400)
tg4 <- subset(train, Code.postal %in% g4)
mean_x4 <- mean(tg4$Surface.reel); mean_y4 <- mean(tg4$Valeur.fonciere)
b4 <- sum((tg4$Surface.reel - mean_x4)*(tg4$Valeur.fonciere - mean_y4)) / sum((tg4$Surface.reel - mean_x4)^2)
a4 <- mean_y4 - b4 * mean_x4
test$Valeur.fonciere[test$Code.postal %in% g4] <- a4 + b4 * test$Surface.reel[test$Code.postal %in% g4]

# --- Groupe 5 (exponentiel) ---
g5 <- c(79180)
tg5 <- subset(train, Code.postal %in% g5 & Valeur.fonciere > 0)
log_y5 <- log(tg5$Valeur.fonciere); mean_x5 <- mean(tg5$Surface.reel); mean_logy5 <- mean(log_y5)
b5 <- sum((tg5$Surface.reel - mean_x5)*(log_y5 - mean_logy5)) / sum((tg5$Surface.reel - mean_x5)^2)
a5 <- exp(mean_logy5 - b5 * mean_x5)
test$Valeur.fonciere[test$Code.postal %in% g5] <- a5 * exp(b5 * test$Surface.reel[test$Code.postal %in% g5])

# --- Groupe 6 (lin�aire) ---
g6 <- c(79190, 79290, 79310, 79320, 79450, 79800)
tg6 <- subset(train, Code.postal %in% g6)
mean_x6 <- mean(tg6$Surface.reel); mean_y6 <- mean(tg6$Valeur.fonciere)
b6 <- sum((tg6$Surface.reel - mean_x6)*(tg6$Valeur.fonciere - mean_y6)) / sum((tg6$Surface.reel - mean_x6)^2)
a6 <- mean_y6 - b6 * mean_x6
test$Valeur.fonciere[test$Code.postal %in% g6] <- a6 + b6 * test$Surface.reel[test$Code.postal %in% g6]

# --- Groupe 7 (lin�aire) ---
g7 <- c(79210, 79370)
tg7 <- subset(train, Code.postal %in% g7)
mean_x7 <- mean(tg7$Surface.reel); mean_y7 <- mean(tg7$Valeur.fonciere)
b7 <- sum((tg7$Surface.reel - mean_x7)*(tg7$Valeur.fonciere - mean_y7)) / sum((tg7$Surface.reel - mean_x7)^2)
a7 <- mean_y7 - b7 * mean_x7
test$Valeur.fonciere[test$Code.postal %in% g7] <- a7 + b7 * test$Surface.reel[test$Code.postal %in% g7]

# --- Groupe 8 (lin�aire) ---
g8 <- c(79230, 79510)
tg8 <- subset(train, Code.postal %in% g8)
mean_x8 <- mean(tg8$Surface.reel); mean_y8 <- mean(tg8$Valeur.fonciere)
b8 <- sum((tg8$Surface.reel - mean_x8)*(tg8$Valeur.fonciere - mean_y8)) / sum((tg8$Surface.reel - mean_x8)^2)
a8 <- mean_y8 - b8 * mean_x8
test$Valeur.fonciere[test$Code.postal %in% g8] <- a8 + b8 * test$Surface.reel[test$Code.postal %in% g8]

# --- Groupe 9 (logarithmique) ---
g9 <- c(79260, 79270)
tg9 <- subset(train, Code.postal %in% g9 & Surface.reel > 0)
log_x9 <- log(tg9$Surface.reel); mean_logx9 <- mean(log_x9); mean_y9 <- mean(tg9$Valeur.fonciere)
b9 <- sum((log_x9 - mean_logx9)*(tg9$Valeur.fonciere - mean_y9)) / sum((log_x9 - mean_logx9)^2)
a9 <- mean_y9 - b9 * mean_logx9
test$Valeur.fonciere[test$Code.postal %in% g9] <- a9 + b9 * log(test$Surface.reel[test$Code.postal %in% g9])

# --- Groupe 10 (logarithmique) ---
g10 <- c(79300, 79360, 79700)
tg10 <- subset(train, Code.postal %in% g10 & Surface.reel > 0)
log_x10 <- log(tg10$Surface.reel); mean_logx10 <- mean(log_x10); mean_y10 <- mean(tg10$Valeur.fonciere)
b10 <- sum((log_x10 - mean_logx10)*(tg10$Valeur.fonciere - mean_y10)) / sum((log_x10 - mean_logx10)^2)
a10 <- mean_y10 - b10 * mean_logx10
test$Valeur.fonciere[test$Code.postal %in% g10] <- a10 + b10 * log(test$Surface.reel[test$Code.postal %in% g10])

# --- Groupe 11 (lin�aire) ---
g11 <- c(79330, 79380)
tg11 <- subset(train, Code.postal %in% g11)
mean_x11 <- mean(tg11$Surface.reel); mean_y11 <- mean(tg11$Valeur.fonciere)
b11 <- sum((tg11$Surface.reel - mean_x11)*(tg11$Valeur.fonciere - mean_y11)) / sum((tg11$Surface.reel - mean_x11)^2)
a11 <- mean_y11 - b11 * mean_x11
test$Valeur.fonciere[test$Code.postal %in% g11] <- a11 + b11 * test$Surface.reel[test$Code.postal %in% g11]

# --- Groupe 12 (logarithmique) ---
g12 <- c(79410)
tg12 <- subset(train, Code.postal %in% g12 & Surface.reel > 0)
log_x12 <- log(tg12$Surface.reel); mean_logx12 <- mean(log_x12); mean_y12 <- mean(tg12$Valeur.fonciere)
b12 <- sum((log_x12 - mean_logx12)*(tg12$Valeur.fonciere - mean_y12)) / sum((log_x12 - mean_logx12)^2)
a12 <- mean_y12 - b12 * mean_logx12
test$Valeur.fonciere[test$Code.postal %in% g12] <- a12 + b12 * log(test$Surface.reel[test$Code.postal %in% g12])

# --- Groupe 13 (puissance) ---
g13 <- c(79460)
tg13 <- subset(train, Code.postal %in% g13 & Surface.reel > 0 & Valeur.fonciere > 0)
log_x13 <- log(tg13$Surface.reel); log_y13 <- log(tg13$Valeur.fonciere)
mean_logx13 <- mean(log_x13); mean_logy13 <- mean(log_y13)
b13 <- sum((log_x13 - mean_logx13)*(log_y13 - mean_logy13)) / sum((log_x13 - mean_logx13)^2)
a13 <- exp(mean_logy13 - b13 * mean_logx13)
test$Valeur.fonciere[test$Code.postal %in% g13] <- a13 * test$Surface.reel[test$Code.postal %in% g13]^b13

# === 5. Export CSV ===
write.csv2(test[, c("id", "Valeur.fonciere")], "prediction.csv", row.names = FALSE)
