-- 1. Créer une vue pour les produits avec leur prix de vente en 2025
CREATE VIEW produits_prix_2025 AS
SELECT p.numPdt, p.libPdt, pr.prixVente
FROM produit p
JOIN prix pr ON p.numPdt = pr.numPdt
WHERE pr.annee = 2025;

-- 2. Réutiliser la vue pour sélectionner les produits dont le prix dépasse 300€
SELECT * FROM produits_prix_2025 WHERE prixVente > 300;

-- 3. Insérer un nouveau produit
INSERT INTO produit (numPdt, libPdt, stockPdt) VALUES (5, 'Sel de Guérande', 700);

-- 4. Insérer le prix d’achat et de vente pour ce produit (différence de 30€ = différence algébrique)
INSERT INTO prix (numPdt, annee, prixAchat, prixVente) VALUES (5, 2025, 250.00, 280.00);

-- 5. Mettre à jour le stock d’un produit (UPDATE)
UPDATE produit SET stockPdt = stockPdt + 200 WHERE numPdt = 1;

-- 6. Supprimer un client (DELETE)
DELETE FROM client WHERE numCli = 12;

-- 7. Ajouter une sortie de produit (concerner + sortie)
INSERT INTO sortie (numSort, dateSort, numCli) VALUES (30002, '2025-01-16 00:00:00', 2);
INSERT INTO concerner (numPdt, numSort, qteSort) VALUES (2, 30002, 900);

-- 8. Requête avec GROUP BY : total des quantités sorties par produit
SELECT numPdt, SUM(qteSort) AS total_qte FROM concerner GROUP BY numPdt;

-- 9. Requête avec GROUP BY + HAVING : produits avec +1000 quantités sorties
SELECT numPdt, SUM(qteSort) AS total_qte FROM concerner GROUP BY numPdt HAVING SUM(qteSort) > 1000;

-- 10. Mise à jour du prix de vente (différence algébrique possible)
UPDATE prix SET prixVente = prixAchat + 50 WHERE numPdt = 1 AND annee = 2025;
