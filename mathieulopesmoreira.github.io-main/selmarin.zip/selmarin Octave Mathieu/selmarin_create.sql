CREATE TABLE `annee` (
  `annee` year(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

CREATE TABLE `client` (
  `numCli` int(11) NOT NULL,
  `nomCli` varchar(50) DEFAULT NULL,
  `precisionCli` varchar(50) NOT NULL,
  `villeCli` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

CREATE TABLE `concerner` (
  `numPdt` int(11) NOT NULL,
  `numSort` int(11) NOT NULL,
  `qteSort` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

CREATE TABLE `entree` (
  `numEnt` int(11) NOT NULL,
  `dateEnt` datetime DEFAULT NULL,
  `qteEnt` double NOT NULL,
  `numSau` int(11) NOT NULL,
  `numPdt` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

CREATE TABLE `prix` (
  `numPdt` int(11) NOT NULL,
  `annee` year(4) NOT NULL,
  `prixAchat` decimal(15,2) NOT NULL,
  `prixVente` decimal(15,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

CREATE TABLE `produit` (
  `numPdt` int(11) NOT NULL,
  `libPdt` varchar(50) DEFAULT NULL,
  `stockPdt` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

CREATE TABLE `saunier` (
  `numSau` int(11) NOT NULL,
  `nomSau` varchar(50) DEFAULT NULL,
  `prenomSau` varchar(50) DEFAULT NULL,
  `villeSau` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

CREATE TABLE `sortie` (
  `numSort` int(11) NOT NULL,
  `dateSort` datetime DEFAULT NULL,
  `numCli` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
