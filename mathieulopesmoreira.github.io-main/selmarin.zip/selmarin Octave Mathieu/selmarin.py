import os
import pandas as pd
import mysql.connector
from mysql.connector import Error

# Paramètres MySQL
DB_CONFIG = {
    "host": "localhost",
    "user": "root",
    "password": "",
    "database": "selmarin"
}

# Dossier contenant les fichiers CSV
CSV_FOLDER = os.path.join(os.path.dirname(__file__), 'selmarinCSV')

# Fonction de connexion à MySQL
def connect_to_mysql():
    try:
        connection = mysql.connector.connect(**DB_CONFIG)
        if connection.is_connected():
            print("Connexion réussie à MySQL")
            return connection
    except Error as e:
        print(f"Erreur de connexion à MySQL: {e}")
        return None

# Fonction pour importer un fichier CSV générique
def import_csv_to_mysql(file_path, table_name, date_columns=None):
    connection = connect_to_mysql()
    if not connection:
        return
    
    cursor = connection.cursor()

    if os.path.exists(file_path):
        print(f"Traitement du fichier : {file_path} pour la table {table_name}")

        df = pd.read_csv(file_path, sep=';', encoding='latin1')

        if date_columns:
            for col in date_columns:
                df[col] = pd.to_datetime(df[col], format="%d/%m/%Y").dt.strftime("%Y-%m-%d")

        for _, row in df.iterrows():
            columns = ", ".join(df.columns)
            placeholders = ", ".join(["%s"] * len(df.columns))
            update_columns = ", ".join([f"{col}=VALUES({col})" for col in df.columns])
            sql = f"INSERT INTO {table_name} ({columns}) VALUES ({placeholders}) ON DUPLICATE KEY UPDATE {update_columns}"
            try:
                cursor.execute(sql, tuple(row))
                connection.commit()
            except Error as e:
                print(f"Erreur lors de l'insertion dans {table_name}: {e}")
                connection.rollback()

        print(f"Données insérées dans {table_name} depuis {file_path}")
    else:
        print(f"Fichier {file_path} non trouvé.")

    cursor.close()
    connection.close()
    print("Importation terminée !")

# Fonction pour importer sortie.csv dans les tables sortie et concerner
def import_sortie_csv(file_path):
    connection = connect_to_mysql()
    if not connection:
        return
    
    cursor = connection.cursor()

    if os.path.exists(file_path):
        print(f"Traitement du fichier : {file_path} pour les tables sortie et concerner")

        df = pd.read_csv(file_path, sep=';', encoding='latin1')
        
        df['dateSort'] = pd.to_datetime(df['dateSort'], format="%d/%m/%Y").dt.strftime("%Y-%m-%d")
        
        for _, row in df.iterrows():
            sql_sortie = """
                INSERT INTO sortie (numSort, dateSort, numCli)
                VALUES (%s, %s, %s)
                ON DUPLICATE KEY UPDATE dateSort=VALUES(dateSort), numCli=VALUES(numCli)
            """
            try:
                cursor.execute(sql_sortie, (row['numSort'], row['dateSort'], row['numCli']))
                connection.commit()
            except Error as e:
                print(f"Erreur lors de l'insertion dans sortie: {e}")
                connection.rollback()

            sql_concerner = """
                INSERT INTO concerner (numSort, numPdt, qteSort)
                VALUES (%s, %s, %s)
                ON DUPLICATE KEY UPDATE numPdt=VALUES(numPdt), qteSort=VALUES(qteSort)
            """
            try:
                cursor.execute(sql_concerner, (row['numSort'], row['numPdt'], row['qteSort']))
                connection.commit()
            except Error as e:
                print(f"Erreur lors de l'insertion dans concerner: {e}")
                connection.rollback()
        
        print("Données insérées dans sortie et concerner depuis sortie.csv")
    else:
        print(f"Fichier {file_path} non trouvé.")
    
    cursor.close()
    connection.close()
    print("Importation terminée !")

# Point d'entrée du script
if __name__ == "__main__":
    import_csv_to_mysql(os.path.join(CSV_FOLDER, 'saunier.csv'), 'saunier')
    import_csv_to_mysql(os.path.join(CSV_FOLDER, 'entree.csv'), 'entree', date_columns=['dateEnt'])
    import_csv_to_mysql(os.path.join(CSV_FOLDER, 'client.csv'), 'client')
    import_sortie_csv(os.path.join(CSV_FOLDER, 'sortie.csv'))
