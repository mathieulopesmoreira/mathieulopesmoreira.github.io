INSERT INTO `saunier` (`numSau`, `nomSau`, `prenomSau`, `villeSau`) VALUES
(1, 'YVAN', 'Pierre', 'Ars-En-RÃ©'),
(2, 'PETIT', 'Marc', 'Loix');

INSERT INTO `produit` (`numPdt`, `libPdt`, `stockPdt`) VALUES
(1, 'Gros sel', 2000),
(2, 'Fleur de sel', 1000);

INSERT INTO `client` (`numCli`, `nomCli`, `precisionCli`, `villeCli`) VALUES
(1, 'CAVANA', 'Marie', 'LA ROCHELLE'),
(2, 'BURLET', 'Michel', 'LAGORD'),
(3, 'PEUTOT', 'Maurice', 'LAGORD'),
(4, 'ORGEVAL', 'Centrale dâ€™Achats', 'SURGERES');

INSERT INTO `sortie` (`numSort`, `dateSort`, `numCli`) VALUES
(20241, '2024-07-16 00:00:00', 1),
(20242, '2024-07-18 00:00:00', 1),
(20243, '2024-08-10 00:00:00', 2);

INSERT INTO `annee` (`annee`) VALUES
(2023),
(2024),
(2025);

INSERT INTO `concerner` (`numPdt`, `numSort`, `qteSort`) VALUES
(1, 20241, 300),
(1, 20242, 200),
(1, 20243, 100),
(2, 20241, 400),
(2, 20243, 500);

INSERT INTO `entree` (`numEnt`, `dateEnt`, `qteEnt`, `numSau`, `numPdt`) VALUES
(20241, '2024-06-16 00:00:00', 1000, 1, 1),
(20242, '2024-06-18 00:00:00', 500, 1, 2),
(20243, '2024-07-10 00:00:00', 1500, 2, 2);

INSERT INTO `prix` (`numPdt`, `annee`, `prixAchat`, `prixVente`) VALUES
(1, 2023, '270.00', '280.00'),
(1, 2024, '270.00', '290.00'),
(1, 2025, '240.00', '300.00'),
(2, 2023, '3900.00', '9500.00'),
(2, 2024, '3800.00', '10000.00'),
(2, 2025, '3500.00', '9000.00');
