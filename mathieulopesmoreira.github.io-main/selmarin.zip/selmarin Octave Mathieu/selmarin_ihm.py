import os
import tkinter as tk
from tkinter import ttk, filedialog, messagebox
from tkinter import scrolledtext, simpledialog
import subprocess
import pandas as pd
import mysql.connector
from PIL import Image, ImageTk  # Pour l'image de fond

# Variables globales pour suivre l'ordre des imports
imported_scripts = set()
user_role = None  # Variable pour suivre le rôle de l'utilisateur connecté

# Connexion MySQL
def connect_db():
    return mysql.connector.connect(host="localhost", user="root", password="")

# Vérifier si la base de données existe
def database_exists():
    conn = connect_db()
    cursor = conn.cursor()
    cursor.execute("SHOW DATABASES LIKE 'selmarin'")
    result = cursor.fetchone()
    cursor.close()
    conn.close()
    return result is not None

# Créer la base de données et les tables si elles n'existent pas
def create_database():
    if database_exists():
        messagebox.showinfo("Info", "La base de données 'selmarin' existe déjà.")
    else:
        conn = connect_db()
        cursor = conn.cursor()
        try:
            cursor.execute("CREATE DATABASE selmarin")
            cursor.execute("USE selmarin")

            # Création des tables
            tables = [
                """
                CREATE TABLE `annee` (
                  `annee` year(4) NOT NULL
                ) ENGINE=InnoDB DEFAULT CHARSET=latin1;
                """,
                """
                CREATE TABLE `client` (
                  `numCli` int(11) NOT NULL,
                  `nomCli` varchar(50) DEFAULT NULL,
                  `precisionCli` varchar(50) NOT NULL,
                  `villeCli` varchar(50) DEFAULT NULL
                ) ENGINE=InnoDB DEFAULT CHARSET=latin1;
                """,
                """
                CREATE TABLE `concerner` (
                  `numPdt` int(11) NOT NULL,
                  `numSort` int(11) NOT NULL,
                  `qteSort` int(11) DEFAULT NULL
                ) ENGINE=InnoDB DEFAULT CHARSET=latin1;
                """,
                """
                CREATE TABLE `entree` (
                  `numEnt` int(11) NOT NULL,
                  `dateEnt` datetime DEFAULT NULL,
                  `qteEnt` double NOT NULL,
                  `numSau` int(11) NOT NULL,
                  `numPdt` int(11) NOT NULL
                ) ENGINE=InnoDB DEFAULT CHARSET=latin1;
                """,
                """
                CREATE TABLE `prix` (
                  `numPdt` int(11) NOT NULL,
                  `annee` year(4) NOT NULL,
                  `prixAchat` decimal(15,2) NOT NULL,
                  `prixVente` decimal(15,2) NOT NULL
                ) ENGINE=InnoDB DEFAULT CHARSET=latin1;
                """,
                """
                CREATE TABLE `produit` (
                  `numPdt` int(11) NOT NULL,
                  `libPdt` varchar(50) DEFAULT NULL,
                  `stockPdt` int(11) DEFAULT NULL
                ) ENGINE=InnoDB DEFAULT CHARSET=latin1;
                """,
                """
                CREATE TABLE `saunier` (
                  `numSau` int(11) NOT NULL,
                  `nomSau` varchar(50) DEFAULT NULL,
                  `prenomSau` varchar(50) DEFAULT NULL,
                  `villeSau` varchar(50) DEFAULT NULL
                ) ENGINE=InnoDB DEFAULT CHARSET=latin1;
                """,
                """
                CREATE TABLE `sortie` (
                  `numSort` int(11) NOT NULL,
                  `dateSort` datetime DEFAULT NULL,
                  `numCli` int(11) NOT NULL
                ) ENGINE=InnoDB DEFAULT CHARSET=latin1;
                """
            ]

            for table in tables:
                cursor.execute(table)

            # Ajout des clés primaires et des contraintes
            alter_tables = [
                """
                ALTER TABLE `annee`
                  ADD PRIMARY KEY (`annee`);
                """,
                """
                ALTER TABLE `client`
                  ADD PRIMARY KEY (`numCli`);
                """,
                """
                ALTER TABLE `concerner`
                  ADD PRIMARY KEY (`numPdt`,`numSort`),
                  ADD KEY `numSort` (`numSort`);
                """,
                """
                ALTER TABLE `entree`
                  ADD PRIMARY KEY (`numEnt`),
                  ADD KEY `numSau` (`numSau`),
                  ADD KEY `numPdt` (`numPdt`);
                """,
                """
                ALTER TABLE `prix`
                  ADD PRIMARY KEY (`numPdt`,`annee`),
                  ADD KEY `annee` (`annee`);
                """,
                """
                ALTER TABLE `produit`
                  ADD PRIMARY KEY (`numPdt`);
                """,
                """
                ALTER TABLE `saunier`
                  ADD PRIMARY KEY (`numSau`);
                """,
                """
                ALTER TABLE `sortie`
                  ADD PRIMARY KEY (`numSort`),
                  ADD KEY `numCli` (`numCli`);
                """,
                """
                ALTER TABLE `concerner`
                  ADD CONSTRAINT `concerner_ibfk_1` FOREIGN KEY (`numPdt`) REFERENCES `produit` (`numPdt`),
                  ADD CONSTRAINT `concerner_ibfk_2` FOREIGN KEY (`numSort`) REFERENCES `sortie` (`numSort`);
                """,
                """
                ALTER TABLE `entree`
                  ADD CONSTRAINT `entree_ibfk_1` FOREIGN KEY (`numSau`) REFERENCES `saunier` (`numSau`),
                  ADD CONSTRAINT `entree_ibfk_2` FOREIGN KEY (`numPdt`) REFERENCES `produit` (`numPdt`);
                """,
                """
                ALTER TABLE `prix`
                  ADD CONSTRAINT `prix_ibfk_1` FOREIGN KEY (`numPdt`) REFERENCES `produit` (`numPdt`),
                  ADD CONSTRAINT `prix_ibfk_2` FOREIGN KEY (`annee`) REFERENCES `annee` (`annee`);
                """,
                """
                ALTER TABLE `sortie`
                  ADD CONSTRAINT `sortie_ibfk_1` FOREIGN KEY (`numCli`) REFERENCES `client` (`numCli`);
                """
            ]

            for alter_table in alter_tables:
                cursor.execute(alter_table)

            conn.commit()
            messagebox.showinfo("Succès", "La base de données 'selmarin' et ses tables ont été créées avec succès.")
        except Exception as e:
            messagebox.showerror("Erreur", f"Erreur lors de la création de la base de données : {e}")
        finally:
            cursor.close()
            conn.close()

# Récupérer les tables
def get_table_names():
    if not database_exists():
        messagebox.showerror("Erreur", "Veuillez ajouter la base de données.")
        return []
    conn = connect_db()
    conn.database = "selmarin"
    cursor = conn.cursor()
    cursor.execute("SHOW FULL TABLES WHERE TABLE_TYPE = 'BASE TABLE'")
    tables = [table[0] for table in cursor.fetchall()]
    cursor.close()
    conn.close()
    return tables

# Récupérer les vues
def get_view_names():
    if not database_exists():
        messagebox.showerror("Erreur", "Veuillez ajouter la base de données.")
        return []
    conn = connect_db()
    conn.database = "selmarin"
    cursor = conn.cursor()
    cursor.execute("SHOW FULL TABLES WHERE TABLE_TYPE = 'VIEW'")
    views = [view[0] for view in cursor.fetchall()]
    cursor.close()
    conn.close()
    return views

def insert_sql_in_editor():
    try:
        current_directory = os.path.dirname(os.path.abspath(__file__))
        file_path = os.path.join(current_directory, "selmarin_requetes.sql")
        with open(file_path, 'r', encoding="utf-8") as file:
            sql_script = file.read()
        sql_text.delete("1.0", tk.END)
        sql_text.insert(tk.END, sql_script)
    except Exception as e:
        messagebox.showerror("Erreur", f"Erreur lors de la lecture du fichier : {e}")

def insert_database_in_editor():
    try:
        current_directory = os.path.dirname(os.path.abspath(__file__))
        file_path = os.path.join(current_directory, "selmarin_insert.sql")
        with open(file_path, 'r', encoding="utf-8") as file:
            sql_script = file.read()
        sql_text.delete("1.0", tk.END)
        sql_text.insert(tk.END, sql_script)
    except Exception as e:
        messagebox.showerror("Erreur", f"Erreur lors de la lecture du fichier : {e}")

def show_table(table_name):
    hide_main_widgets()
    conn = connect_db()
    conn.database = "selmarin"
    df = pd.read_sql(f"SELECT * FROM {table_name}", conn)
    conn.close()

    table_window = tk.Toplevel(root)
    table_window.title(table_name)

    tree = ttk.Treeview(table_window, selectmode="browse", columns=list(df.columns), show="headings")

    for column in df.columns:
        tree.heading(column, text=column, command=lambda c=column: sort_treeview(tree, c, False))
        tree.column(column, width=100)

    for _, row in df.iterrows():
        tree.insert("", "end", values=list(row))

    tree.pack(expand=True, fill='both')

    def export_to_csv():
        file_path = filedialog.asksaveasfilename(defaultextension=".csv",
                                                 filetypes=[("CSV files", "*.csv"), ("All Files", "*.*")],
                                                 title="Enregistrer sous")
        if file_path:
            df.to_csv(file_path, index=False, encoding='utf-8', sep=';')
            messagebox.showinfo("Succès", f"Données exportées sous {file_path}")

    def insert_data():
        if user_role != "admin":
            messagebox.showerror("Erreur", "Vous n'avez pas les droits nécessaires pour insérer des données.")
            return
        data = {col: simpledialog.askstring("Insérer", f"Valeur pour {col}:") for col in df.columns}
        if None in data.values(): return
        conn = connect_db()
        conn.database = "selmarin"
        cursor = conn.cursor()
        columns = ', '.join(data.keys())
        values = ', '.join([f'"{v}"' for v in data.values()])
        query = f"INSERT INTO {table_name} ({columns}) VALUES ({values})"

        try:
            cursor.execute(query)
            conn.commit()
            messagebox.showinfo("Succès", "Données insérées avec succès.")
            tree.insert("", "end", values=list(data.values()))
        except Exception as e:
            messagebox.showerror("Erreur", str(e))
        cursor.close()
        conn.close()

    def delete_selected():
        if user_role != "admin":
            messagebox.showerror("Erreur", "Vous n'avez pas les droits nécessaires pour supprimer des données.")
            return
        selected_item = tree.selection()
        if not selected_item:
            messagebox.showwarning("Avertissement", "Sélectionnez une ligne à supprimer.")
            return
        values = tree.item(selected_item, "values")
        primary_key = df.columns[0]
        primary_value = values[0]

        conn = connect_db()
        conn.database = "selmarin"
        cursor = conn.cursor()
        try:
            cursor.execute("SET FOREIGN_KEY_CHECKS=0;")
            cursor.execute(f"DELETE FROM {table_name} WHERE {primary_key} = '{primary_value}'")
            conn.commit()
            cursor.execute("SET FOREIGN_KEY_CHECKS=1;")
            tree.delete(selected_item)
            messagebox.showinfo("Succès", "Ligne supprimée.")
        except Exception as e:
            messagebox.showerror("Erreur", str(e))
        cursor.close()
        conn.close()

    def search_data():
        search_term = simpledialog.askstring("Rechercher", "Entrez le terme de recherche:")
        if search_term:
            filtered_df = df[df.apply(lambda row: row.astype(str).str.contains(search_term).any(), axis=1)]
            show_dataframe(filtered_df)

    ttk.Button(table_window, text="Exporter en CSV", command=export_to_csv).pack(side=tk.LEFT, padx=10, pady=10)
    ttk.Button(table_window, text="Insérer", command=insert_data).pack(side=tk.LEFT, padx=10, pady=10)
    ttk.Button(table_window, text="Supprimer", command=delete_selected).pack(side=tk.LEFT, padx=10, pady=10)
    ttk.Button(table_window, text="Rechercher", command=search_data).pack(side=tk.LEFT, padx=10, pady=10)
    ttk.Button(table_window, text="Retour", command=lambda: return_to_tables(table_window)).pack(side=tk.LEFT, padx=10, pady=10)

    # Assure que la fenêtre du DataFrame reste au-dessus
    table_window.lift()
    table_window.attributes('-topmost', True)

def show_table_buttons():
    hide_main_widgets()
    for table in get_table_names():
        ttk.Button(button_frame, text=table, command=lambda t=table: show_table(t)).pack(pady=5)
    view_button.pack(pady=20)
    return_button.pack(pady=20)

def show_views():
    hide_main_widgets()
    for view in get_view_names():
        ttk.Button(button_frame, text=view, command=lambda v=view: show_table(v)).pack(pady=5)
    return_view_button.pack(pady=20)

def hide_main_widgets():
    for widget in button_frame.winfo_children():
        widget.pack_forget()

def delete_all_data():
    if user_role != "admin":
        messagebox.showerror("Erreur", "Vous n'avez pas les droits nécessaires pour supprimer toutes les données.")
        return
    if not database_exists():
        messagebox.showerror("Erreur", "Veuillez ajouter la base de données.")
        return
    try:
        conn = connect_db()
        conn.database = "selmarin"
        cursor = conn.cursor()
        cursor.execute("SET FOREIGN_KEY_CHECKS = 0;")
        cursor.execute("SHOW TABLES;")
        tables = cursor.fetchall()
        cursor.execute("SHOW FULL TABLES WHERE TABLE_TYPE = 'VIEW';")
        views = {view[0] for view in cursor.fetchall()}

        for table in tables:
            table_name = table[0]
            if table_name not in views:
                cursor.execute(f"DELETE FROM {table_name};")
            else:
                cursor.execute(f"DROP VIEW IF EXISTS {table_name};")

        cursor.execute("SET FOREIGN_KEY_CHECKS = 1;")
        conn.commit()
        messagebox.showinfo("Succès", "Toutes les tables ont été vidées")
    except Exception as e:
        messagebox.showerror("Erreur", f"Erreur lors de la suppression : {e}")
    finally:
        cursor.close()
        conn.close()

def return_to_initial():
    hide_main_widgets()
    visualize_button.pack(pady=20)
    if user_role == "admin":
        import_csv_button.pack(pady=20)
        sql_editor_button.pack(pady=20)
        export_all_button.pack(pady=20)
        clear_all_button.pack(pady=20)
        add_database_button.pack(pady=20)  # Ajouter le bouton pour créer la base de données
    change_user_button.pack(pady=20)  # Ajouter le bouton pour changer de type d'utilisateur
    quit_button.pack(side=tk.BOTTOM, pady=20)  # Place the quit button at the bottom
    welcome_label.place_forget()
    start_button.place_forget()
    button_frame.place(relx=0.5, rely=0.5, anchor=tk.CENTER, width=1000, height=800)

def return_to_tables(window):
    window.destroy()
    show_table_buttons()

def execute_sql():
    if user_role != "admin":
        messagebox.showerror("Erreur", "Vous n'avez pas les droits nécessaires pour exécuter des scripts SQL.")
        return
    if not database_exists():
        messagebox.showerror("Erreur", "Veuillez ajouter la base de données.")
        return
    sql_script = sql_text.get("1.0", tk.END)
    conn = connect_db()
    conn.database = "selmarin"
    cursor = conn.cursor()
    try:
        statements = sql_script.split(';')
        for statement in statements:
            statement = statement.strip()
            if statement:
                if statement.upper().startswith("SELECT"):
                    cursor.execute(statement)
                    results = cursor.fetchall()
                    show_dataframe(pd.DataFrame(results, columns=[desc[0] for desc in cursor.description]))
                else:
                    cursor.execute(statement)
        conn.commit()
        result_label.config(text="Script exécuté avec succès.")
    except Exception as e:
        result_label.config(text=f"Erreur: {e}")
    finally:
        cursor.close()
        conn.close()

def open_sql_editor():
    if user_role != "admin":
        messagebox.showerror("Erreur", "Vous n'avez pas les droits nécessaires pour accéder à l'éditeur SQL.")
        return
    hide_main_widgets()
    global sql_text, result_label, query_var
    sql_text = scrolledtext.ScrolledText(button_frame, width=80, height=20)
    sql_text.pack(pady=10)
    ttk.Button(button_frame, text="Exécuter", command=execute_sql).pack(pady=10)
    result_label = ttk.Label(button_frame, text="")
    result_label.pack(pady=10)

    # Titre pour la liste déroulante
    query_label = tk.Label(button_frame, text="Insérer requêtes question", font=("Arial", 12, "bold"))
    query_label.pack(pady=5)

    # Liste déroulante pour sélectionner les requêtes
    query_var = tk.StringVar()
    query_dropdown = ttk.Combobox(button_frame, textvariable=query_var, font=("Arial", 12), width=50, state="readonly")
    query_dropdown['values'] = [
        "1. Créer une vue pour les produits avec leur prix de vente en 2025",
        "2. Réutiliser la vue pour sélectionner les produits dont le prix dépasse 300€",
        "3. Insérer un nouveau produit",
        "4. Insérer le prix d’achat et de vente pour ce produit (différence de 30€ = différence algébrique)",
        "5. Mettre à jour le stock d’un produit (UPDATE)",
        "6. Supprimer un client (DELETE)",
        "7. Ajouter une sortie de produit (concerner + sortie)",
        "8. Requête avec GROUP BY : total des quantités sorties par produit",
        "9. Requête avec GROUP BY + HAVING : produits avec +1000 quantités sorties",
        "10. Mise à jour du prix de vente (différence algébrique possible)"
    ]
    query_dropdown.pack(pady=10)
    query_dropdown.bind("<<ComboboxSelected>>", load_selected_query)

    load_database_button = ttk.Button(button_frame, text="Insérer les requêtes de base", command=insert_database_in_editor)
    load_database_button.pack(pady=20)

    load_custom_script_button = ttk.Button(button_frame, text="Charger votre script SQL", command=load_sql_script)
    load_custom_script_button.pack(pady=10)

    ttk.Button(button_frame, text="Retour", command=return_to_initial).pack(pady=10)

def load_selected_query(event):
    query_number = query_var.get().split('.')[0]
    queries = {
        "1": """CREATE VIEW produits_prix_2025 AS
                SELECT p.numPdt, p.libPdt, pr.prixVente
                FROM produit p
                JOIN prix pr ON p.numPdt = pr.numPdt
                WHERE pr.annee = 2025;""",
        "2": "SELECT * FROM produits_prix_2025 WHERE prixVente > 300;",
        "3": "INSERT INTO produit (numPdt, libPdt, stockPdt) VALUES (5, 'Sel de Guérande', 700);",
        "4": "INSERT INTO prix (numPdt, annee, prixAchat, prixVente) VALUES (5, 2025, 250.00, 280.00);",
        "5": "UPDATE produit SET stockPdt = stockPdt + 200 WHERE numPdt = 1;",
        "6": "DELETE FROM client WHERE numCli = 12;",
        "7": """INSERT INTO sortie (numSort, dateSort, numCli) VALUES (30002, '2025-01-16 00:00:00', 2);
                INSERT INTO concerner (numPdt, numSort, qteSort) VALUES (2, 30002, 900);""",
        "8": "SELECT numPdt, SUM(qteSort) AS total_qte FROM concerner GROUP BY numPdt;",
        "9": "SELECT numPdt, SUM(qteSort) AS total_qte FROM concerner GROUP BY numPdt HAVING SUM(qteSort) > 1000;",
        "10": "UPDATE prix SET prixVente = prixAchat + 50 WHERE numPdt = 1 AND annee = 2025;"
    }
    selected_query = queries.get(query_number)
    if selected_query:
        sql_text.delete("1.0", tk.END)
        sql_text.insert(tk.END, selected_query)

def show_dataframe(df):
    dataframe_window = tk.Toplevel(root)
    dataframe_window.title("Résultats de la requête")

    tree = ttk.Treeview(dataframe_window, selectmode="browse", columns=list(df.columns), show="headings")

    for column in df.columns:
        tree.heading(column, text=column, command=lambda c=column: sort_treeview(tree, c, False))
        tree.column(column, width=100)

    for _, row in df.iterrows():
        tree.insert("", "end", values=list(row))

    tree.pack(expand=True, fill='both')

    # Assure que la fenêtre du DataFrame reste au-dessus
    dataframe_window.lift()
    dataframe_window.attributes('-topmost', True)

def export_all_to_excel():
    if user_role != "admin":
        messagebox.showerror("Erreur", "Vous n'avez pas les droits nécessaires pour exporter la base de données.")
        return
    if not database_exists():
        messagebox.showerror("Erreur", "Veuillez ajouter la base de données.")
        return
    conn = connect_db()
    conn.database = "selmarin"
    cursor = conn.cursor()
    tables = get_table_names()

    file_path = filedialog.asksaveasfilename(defaultextension=".xlsx",
                                             initialfile="base_de_donnees.xlsx",
                                             filetypes=[("Excel files", "*.xlsx"), ("All Files", "*.*")],
                                             title="Enregistrer toute la base sous")

    if file_path:
        with pd.ExcelWriter(file_path, engine='xlsxwriter') as writer:
            for table_name in tables:
                df = pd.read_sql(f"SELECT * FROM {table_name}", conn)
                df.to_excel(writer, sheet_name=table_name, index=False)
            messagebox.showinfo("Succès", f"Toutes les tables ont été exportées sous {file_path}")
    conn.close()

def show_warning():
    messagebox.showwarning("Avertissement", "Avant d'importer les CSV, assurez-vous que vous avez importé les requêtes de base.")

def import_csv_menu():
    if user_role != "admin":
        messagebox.showerror("Erreur", "Vous n'avez pas les droits nécessaires pour importer des fichiers CSV.")
        return
    show_warning()  # Afficher l'avertissement avant de montrer les boutons d'importation
    hide_main_widgets()
    ttk.Button(button_frame, text="Importer Saunier", command=lambda: import_csv("saunier.py")).pack(pady=5)
    ttk.Button(button_frame, text="Importer Entrée", command=lambda: import_csv("entree.py")).pack(pady=5)
    ttk.Button(button_frame, text="Importer Client", command=lambda: import_csv("client.py")).pack(pady=5)
    ttk.Button(button_frame, text="Importer Sortie", command=lambda: import_csv("sortie.py")).pack(pady=5)
    ttk.Button(button_frame, text="Importer les 4 fichiers CSV", command=lambda: import_csv("selmarin.py")).pack(pady=5)
    ttk.Button(button_frame, text="Retour", command=return_to_initial).pack(pady=20)

def import_csv(script_name):
    global imported_scripts
    if script_name == "entree.py" and "saunier.py" not in imported_scripts:
        messagebox.showerror("Erreur", "Vous devez d'abord importer 'saunier.py' avant 'entree.py'.")
        return
    try:
        result = subprocess.run(['python', script_name], capture_output=True, text=True)
        if result.returncode == 0:
            messagebox.showinfo("Succès", f"Fichier CSV importé avec succès via {script_name}.")
            imported_scripts.add(script_name)
        else:
            messagebox.showerror("Erreur", f"Erreur lors de l'importation : {result.stderr}")
    except Exception as e:
        messagebox.showerror("Erreur", f"Impossible d'exécuter le script : {str(e)}")

def show_home_page():
    hide_main_widgets()
    button_frame.place_forget()  # Hide the button frame
    global welcome_label, start_button
    welcome_label = tk.Label(root, text="Bienvenue dans l'espace de gestion de données de Sel Marin", font=("Arial", 36, "bold"), bg="#b8e2f4", fg="black", borderwidth=1, relief="solid")
    welcome_label.place(relx=0.5, rely=0.4, anchor=tk.CENTER)
    start_button = ttk.Button(root, text="Commencer", command=show_login_page, style="TButton")
    start_button.place(relx=0.5, rely=0.5, anchor=tk.CENTER)

def show_login_page():
    hide_main_widgets()
    button_frame.place_forget()  # Hide the button frame
    global login_frame, role_var, password_entry

    login_frame = tk.Frame(root, bg="#b8e2f4", bd=5, relief="solid")
    login_frame.place(relx=0.5, rely=0.5, anchor=tk.CENTER, width=400, height=300)

    role_label = tk.Label(login_frame, text="Rôle:", font=("Arial", 14))
    role_label.pack(pady=10)

    role_var = tk.StringVar()
    role_dropdown = ttk.Combobox(login_frame, textvariable=role_var, font=("Arial", 12), width=20, state="readonly")
    role_dropdown['values'] = ["user", "admin"]
    role_dropdown.pack(pady=10)

    password_label = tk.Label(login_frame, text="Mot de passe:", font=("Arial", 14))
    password_label.pack(pady=10)

    password_entry = ttk.Entry(login_frame, show="*", font=("Arial", 12), width=20)
    password_entry.pack(pady=10)

    login_button = ttk.Button(login_frame, text="Connexion", command=verify_login)
    login_button.pack(pady=20)

def verify_login():
    global user_role
    role = role_var.get()
    password = password_entry.get()

    if role == "user" and password == "bieber":
        user_role = "user"
        messagebox.showinfo("Succès", "Connexion réussie en tant qu'utilisateur.")
        login_frame.place_forget()
        return_to_initial()
    elif role == "admin" and password == "ibazizou":
        user_role = "admin"
        messagebox.showinfo("Succès", "Connexion réussie en tant qu'administrateur.")
        login_frame.place_forget()
        return_to_initial()
    else:
        messagebox.showerror("Erreur", "Rôle ou mot de passe incorrect.")

def change_user_type():
    global user_role
    user_role = None
    show_login_page()

def sort_treeview(tree, col, reverse):
    data = [(tree.set(child, col), child) for child in tree.get_children('')]
    data.sort(reverse=reverse)
    for index, (val, child) in enumerate(data):
        tree.move(child, '', index)
    tree.heading(col, command=lambda: sort_treeview(tree, col, not reverse))

def load_sql_script():
    file_path = filedialog.askopenfilename(filetypes=[("SQL files", "*.sql"), ("All Files", "*.*")],
                                           title="Charger un script SQL")
    if file_path:
        with open(file_path, 'r', encoding="utf-8") as file:
            sql_script = file.read()
        sql_text.delete("1.0", tk.END)
        sql_text.insert(tk.END, sql_script)


root = tk.Tk()
root.title("Selmarin Database Viewer")
root.attributes('-fullscreen', True)
root.configure(bg="white")

# Style des boutons
style = ttk.Style()
style.configure("TButton",
                background="#b8e2f4",
                foreground="black",
                font=("Arial", 14, "bold"),
                borderwidth=2,
                relief="solid",
                padding=10)

# === IMAGE DE FOND ===
try:
    bg_image = Image.open("fondbleu.jpg")
    screen_width = root.winfo_screenwidth()
    screen_height = root.winfo_screenheight()
    bg_image = bg_image.resize((screen_width, screen_height), Image.LANCZOS)
    bg_photo = ImageTk.PhotoImage(bg_image)
    background_label = tk.Label(root, image=bg_photo)
    background_label.place(x=0, y=0, relwidth=1, relheight=1)
except Exception as e:
    messagebox.showerror("Erreur", f"Impossible de charger le fond : {e}")

# Frame pour les boutons avec des marges pour une meilleure intégration
button_frame = tk.Frame(root, bg="#b8e2f4", bd=5, relief="solid")
button_frame.place(relx=0.5, rely=0.5, anchor=tk.CENTER, width=1000, height=800)  # Augmenter la taille de la frame

# Ajouter des marges internes pour une meilleure apparence
button_frame.grid_columnconfigure(0, weight=1)
button_frame.grid_rowconfigure(0, weight=1)
button_frame.grid_rowconfigure(10, weight=1)  # Ajouter une marge en bas

# Afficher la page d'accueil
show_home_page()

# Boutons principaux
visualize_button = ttk.Button(button_frame, text="Visualiser les tables", command=show_table_buttons)
sql_editor_button = ttk.Button(button_frame, text="Exécuter script SQL", command=open_sql_editor)
import_csv_button = ttk.Button(button_frame, text="Importer CSV", command=import_csv_menu)
export_all_button = ttk.Button(button_frame, text="Exporter toute la base de données", command=export_all_to_excel)
view_button = ttk.Button(button_frame, text="Afficher les vues", command=show_views)
return_button = ttk.Button(button_frame, text="Retour", command=return_to_initial)
return_view_button = ttk.Button(button_frame, text="Retour", command=show_table_buttons)
clear_all_button = ttk.Button(button_frame, text="Vider toutes les tables", command=delete_all_data)
add_database_button = ttk.Button(button_frame, text="Ajouter la base de données Selmarin et ses tables", command=create_database)
change_user_button = ttk.Button(button_frame, text="Changer de type d'utilisateur", command=change_user_type)
quit_button = ttk.Button(button_frame, text="Quitter", command=root.destroy)





# Afficher les boutons au-dessus du fond
for widget in root.winfo_children():
    widget.lift()

# Touche Échap pour quitter le plein écran
def exit_fullscreen(event):
    root.attributes('-fullscreen', False)

root.bind("<Escape>", exit_fullscreen)

root.mainloop()
