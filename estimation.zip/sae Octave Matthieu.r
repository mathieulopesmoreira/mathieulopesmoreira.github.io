


setwd('C:\Users\Romer Octave\OneDrive - Université de Poitiers\But sd\s2\SAE\ibazizen')

# Lire le fichier CSV
table <- read.csv2("population_francaise_communes.csv", sep=";", dec=",", header=TRUE)

# Filtrer les données pour la Nouvelle-Aquitaine
donnees <- table[table$Code.région == "75", c("Code.département", "Commune", "Population.totale")]

library(sampling)


# Afficher les 6 premières lignes de la table
head(donnees)



# Créer la table U
U <- donnees$Commune
head(U)

# Calculer le nombre total de communes
N <- length(U)

# Afficher le nombre total de communes
print(paste("Le nombre total de communes dans la région est :", N))

# Supprimer les espaces dans la colonne "Population.totale" et convertir en numérique
donnees$Population.totale <- as.numeric(gsub(" ", "", donnees$Population.totale))

# Calculer le nombre total d'habitants
T <- sum(donnees$Population.totale, na.rm = TRUE)

# Afficher le nombre total d'habitants
print(paste("Le nombre total d'habitants dans la région est :", T))





# Tirage aléatoire simple d'un échantillon de taille n
n <- 100
E <- sample(U, n)  
head(E)  # Afficher les 6 premières valeurs de l'échantillon tiré

# Créer une nouvelle table "donnees1" contenant les communes sélectionnées,
# leur département et leur nombre d'habitants
donnees1 <- donnees[donnees$Commune %in% E, ]

# Afficher les 6 premières lignes de la table "donnees1"
head(donnees1)

# Calculer la moyenne de la population totale dans l'échantillon
xbar <- mean(donnees1$Population.totale)
xbar  # Afficher la moyenne

# Calculer l'intervalle de confiance à 95 % pour la moyenne
idcmoy <- t.test(donnees1$Population.totale)$conf.int
idcmoy  # Afficher l'intervalle de confiance

# Estimation du nombre total d’habitants dans la population totale
T_est <- N * xbar
T_est  # Afficher l’estimation du total

# Calculer l’intervalle de confiance à 95 % pour le total
idcT <- idcmoy * N
idcT  # Afficher l’intervalle de confiance pour le total

# Calcul de la marge d'erreur de l’estimation du total
marge <- (idcT[2] - idcT[1]) / 2
marge  # Afficher la marge d'erreur







#*************** Partie1.2 *****************



# Quintile de la variable "Population.totale" 
summary(donnees$Population.totale)

# Création d'une nouvelle colonne "strate" selon les classes de population
donnees$strate <- cut(
  donnees$Population.totale,
  breaks = c(0, 250, 500, 1000, Inf),  # Définition des bornes des strates
  labels = c("Strate 1", "Strate 2", "Strate 3", "Strate 4"),  # Noms des strates
  include.lowest = TRUE  # Inclure la valeur minimale dans le premier intervalle
)

# Création d'une nouvelle table avec les colonnes utiles : "Commune", "Population.totale" et "strate"
donneesstrat <- donnees[, c("Commune", "Population.totale", "strate")]

# Affichage des 6 premières lignes de la table "donneesstrat"
head(donneesstrat)
#Question 3

# Trier les données par strate
data <- donneesstrat[order(donneesstrat$strate), ]
head(data)





# Effectifs par strate
Nh <- table(data$strate)
Nh

# Taille totale de la population
N <- sum(Nh)
N

# Poids des strates
gh <- Nh / N
gh

# Taille de l’échantillon total
n <- 100

# Effectifs proportionnels à tirer par strate
nh <- round(c(n * Nh[1]/N, n * Nh[2]/N, n * Nh[3]/N, n * Nh[4]/N))

# Ajustement si la somme != 100
diff_n <- n - sum(nh)
if (diff_n != 0) {
  nh[which.max(nh)] <- nh[which.max(nh)] + diff_n
}
nh

# Taux de sondage dans chaque strate
fh <- nh / Nh
fh

# Tirage de l'échantillon stratifié sans remise
st <- strata(data, stratanames = c("strate"), size = nh, method = "srswor")
data1 <- getdata(data, st)

# Afficher les premières lignes et taille de l’échantillon
head(data1)
length(data1$Commune)  # Devrait être 100





# Séparation de l'échantillon selon les strates
ech1 <- data1[data1$Stratum == 1, ]  # Sous-échantillon de la strate 1
ech2 <- data1[data1$Stratum == 2, ]  # Sous-échantillon de la strate 2
ech3 <- data1[data1$Stratum == 3, ]  # Sous-échantillon de la strate 3
ech4 <- data1[data1$Stratum == 4, ]  # Sous-échantillon de la strate 4

# Moyennes des 4 sous-échantillons
m1 <- mean(ech1$Population.totale)  # Moyenne pour la strate 1
m2 <- mean(ech2$Population.totale)  # Moyenne pour la strate 2
m3 <- mean(ech3$Population.totale)  # Moyenne pour la strate 3
m4 <- mean(ech4$Population.totale)  # Moyenne pour la strate 4

# Variances des 4 sous-échantillons
var1 <- var(ech1$Population.totale)  # Variance pour la strate 1
var2 <- var(ech2$Population.totale)  # Variance pour la strate 2
var3 <- var(ech3$Population.totale)  # Variance pour la strate 3
var4 <- var(ech4$Population.totale)  # Variance pour la strate 4



# Moyenne stratifiée pondérée des 4 sous-échantillons
Xbarst <- (Nh[1]*m1 + Nh[2]*m2 + Nh[3]*m3 + Nh[4]*m4) / N

# Estimation de la variance de la moyenne stratifiée (Xbarst)
varXbarst <- ((gh[1])^2) * (1 - fh[1]) * var1 / nh[1] +
  ((gh[2])^2) * (1 - fh[2]) * var2 / nh[2] +
  ((gh[3])^2) * (1 - fh[3]) * var3 / nh[3] +
  ((gh[4])^2) * (1 - fh[4]) * var4 / nh[4]

# Intervalle de confiance à 95 % pour la moyenne stratifiée
alpha <- 0.05
binf <- Xbarst - qnorm(1 - alpha / 2) * sqrt(varXbarst)
bsup <- Xbarst + qnorm(1 - alpha / 2) * sqrt(varXbarst)
idcmoy <- c(binf, bsup)  # Intervalle de confiance pour la moyenne

# Estimation du total de la population à partir de la moyenne stratifiée
Tstr <- N * Xbarst
Tstr  # Affiche l’estimation du total

# Intervalle de confiance pour le total de la population
binf <- idcmoy[1] * N
bsup <- idcmoy[2] * N
idcT <- c(binf, bsup)
idcT  # Affiche l’intervalle de confiance pour le total

# Marge d’erreur de l’estimation du total
marge <- (idcT[2] - idcT[1]) / 2
marge  # Affiche la marge d'erreur



#*************** Partie2 *****************

# Lire le fichier CSV
data  <- read.csv2("EnqueteSportEtudiant2024.csv", sep=";", dec=",", header=TRUE)

head(data) 

#Le fichier EnqueteSportEtudiant2024.csv contient les réponses de plusieurs étudiants à une enquête sur leurs habitudes de vie. Chaque ligne représente un individu, et chaque colonne une variable.

#On y trouve des variables qualitatives (sexe, sport pratiqué, motivation, niveau d’étude) et des variables quantitatives (âge, taille, poids, heures de sommeil, fréquence du sport). Ce tableau permet d’analyser les liens entre la pratique du sport et d’autres facteurs personnels.


# Sexe vs Sport
table_sexe_sport <- table(data$sport, data$sexe)
print(table_sexe_sport)

# Niveau d’étude vs Sport
table_niv_sport <- table(data$sport, data$niveau)
print(table_niv_sport)


# Fumeur vs Sport
table_fumeur_sport <- table(data$sport, data$fumer)
print(table_fumeur_sport)


# Sante vs Sport
table_transport_sport <- table(data$sport, data$sante)
print(table_transport_sport)


# Création de la fonction pour calculer le Khi², la p-value et le V de Cramér
calculer_khi2_vcramer <- function(table_croisee) {
  test_result <- chisq.test(table_croisee)
  khi2 <- test_result$statistic
  p_value <- test_result$p.value
  
  # Calcul du V de Cramér
  n <- sum(table_croisee)
  q <- nrow(table_croisee)
  r <- ncol(table_croisee)
  m <- min(q - 1, r - 1)
  v_cramer <- sqrt(khi2 / (n * m))
  
  return(list(khi2 = khi2, p = p_value, v = v_cramer))
}

# Appliquer à toutes les variables croisées avec sport

# Sexe
tc_sexe <- table(data$sport, data$sexe)
res_sexe <- calculer_khi2_vcramer(tc_sexe)

# Niveau
tc_niveau <- table(data$sport, data$niveau)
res_niveau <- calculer_khi2_vcramer(tc_niveau)

# Fumeur
tc_fumer <- table(data$sport, data$fumer)
res_fumer <- calculer_khi2_vcramer(tc_fumer)

# Santé
tc_sante <- table(data$sport, data$sante)
res_sante <- calculer_khi2_vcramer(tc_sante)

# Affichage des résultats
cat("Résultats Khi² et V de Cramér\n")
cat("Sport vs Sexe :      p =", res_sexe$p, ", V de Cramér =", res_sexe$v, "\n")
cat("Sport vs Niveau :    p =", res_niveau$p, ", V de Cramér =", res_niveau$v, "\n")
cat("Sport vs Fumer :     p =", res_fumer$p, ", V de Cramér =", res_fumer$v, "\n")
cat("Sport vs Santé :     p =", res_sante$p, ", V de Cramér =", res_sante$v, "\n")

# Regrouper les résultats dans une liste
tests <- list(
  "Sexe" = res_sexe,
  "Niveau" = res_niveau,
  "Fumer" = res_fumer,
  "Santé" = res_sante
)

# Extraire uniquement les tests significatifs
tests_significatifs <- lapply(tests, function(x) if (x$p < 0.05) x else NULL)
tests_significatifs <- tests_significatifs[!sapply(tests_significatifs, is.null)]

# Construire un tableau des résultats significatifs
v_cramer_values <- sapply(tests_significatifs, function(x) x$v)

# Trouver la liaison la plus forte (max V de Cramér)
max_v <- max(v_cramer_values)
nom_max_v <- names(which.max(v_cramer_values))

# Construire un tableau en data.frame
resultats_df <- data.frame(
  Test = names(v_cramer_values),
  V_de_Cramer = v_cramer_values
)

# Afficher le tableau avec soulignement (en console on peut juste afficher un message)
print(resultats_df)
cat("\nLa liaison la plus forte est pour :", nom_max_v, "avec un V de Cramér de", max_v, "\n")